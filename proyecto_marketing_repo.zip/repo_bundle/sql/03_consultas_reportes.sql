/* =============================================================================
   ARCHIVO  : 03_consultas_reportes.sql
   MOTOR    : PostgreSQL 13+
   OBJETIVO : Consultas listas para validar cada página del reporte del PDF.
              Power BI puede tomarlas directamente (Obtener Datos > PostgreSQL
              > Consulta SQL avanzada) o consumir las vistas analytics.v_*.
   ============================================================================= */

/* =============================================================================
   REPORTE 1 — COMERCIAL (sección 6.1)
   ============================================================================= */

/* Q1.1 — KPIs globales */
SELECT
    SUM(gasto)                                            AS gasto_total,
    SUM(ingresos_atribuidos)                              AS ingresos_totales,
    SUM(leads)                                            AS leads_totales,
    SUM(conversiones)                                     AS conversiones_totales,
    SUM(ingresos_atribuidos)::NUMERIC / NULLIF(SUM(gasto),0)        AS roas,
    SUM(clicks)::NUMERIC           / NULLIF(SUM(impresiones),0)    AS ctr,
    SUM(gasto)::NUMERIC            / NULLIF(SUM(leads),0)          AS cpl,
    SUM(gasto)::NUMERIC            / NULLIF(SUM(conversiones),0)   AS cpa
FROM analytics.v_metricas_diarias;

/* Q1.2 — Tendencia mensual: gasto vs ingresos */
SELECT  anio_mes,
        SUM(gasto)               AS gasto,
        SUM(ingresos_atribuidos) AS ingresos,
        SUM(ingresos_atribuidos) - SUM(gasto) AS resultado_neto
FROM analytics.v_metricas_diarias
GROUP BY anio_mes
ORDER BY anio_mes;

/* Q1.3 — Top 10 clientes por ROAS (umbral de gasto para evitar outliers) */
SELECT  nombre_cliente,
        SUM(gasto)               AS gasto,
        SUM(ingresos_atribuidos) AS ingresos,
        SUM(ingresos_atribuidos)::NUMERIC / NULLIF(SUM(gasto),0) AS roas
FROM analytics.v_metricas_diarias
GROUP BY nombre_cliente
HAVING SUM(gasto) >= 1000
ORDER BY roas DESC
LIMIT 10;

/* Q1.4 — Top 10 campañas ganadoras (por ingresos) */
SELECT  nombre_campana, plataforma, objetivo, nombre_cliente,
        gasto, ingresos_atribuidos, roas, leads, conversiones
FROM analytics.v_performance_campana
ORDER BY ingresos_atribuidos DESC
LIMIT 10;

/* Q1.5 — Desempeño por plataforma */
SELECT  plataforma,
        SUM(gasto)               AS gasto,
        SUM(ingresos_atribuidos) AS ingresos,
        SUM(leads)               AS leads,
        SUM(conversiones)        AS conversiones,
        SUM(ingresos_atribuidos)::NUMERIC / NULLIF(SUM(gasto),0) AS roas,
        SUM(gasto)::NUMERIC            / NULLIF(SUM(leads),0)  AS cpl
FROM analytics.v_metricas_diarias
GROUP BY plataforma
ORDER BY roas DESC;

/* Q1.6 — Desempeño por objetivo de campaña */
SELECT  objetivo,
        SUM(gasto)               AS gasto,
        SUM(ingresos_atribuidos) AS ingresos,
        SUM(ingresos_atribuidos)::NUMERIC / NULLIF(SUM(gasto),0) AS roas
FROM analytics.v_metricas_diarias
GROUP BY objetivo
ORDER BY roas DESC;


/* =============================================================================
   REPORTE 2 — INTERNO: Cartera y Rentabilidad (sección 6.2)
   ============================================================================= */

/* Q2.1 — Maestra cliente-mes */
SELECT *
FROM analytics.v_resumen_mensual_cliente
ORDER BY anio_mes, nombre_cliente;

/* Q2.2 — Rentabilidad por cliente (acumulado) */
SELECT
    nombre_cliente,
    industria,
    estado_cliente,
    SUM(facturacion_total)   AS facturacion,
    SUM(costo_interno)       AS costo_interno,
    SUM(margen)              AS margen,
    SUM(margen)::NUMERIC / NULLIF(SUM(facturacion_total),0) AS margen_pct,
    SUM(gasto)               AS gasto_ads,
    SUM(ingresos_atribuidos) AS ingresos_atribuidos,
    SUM(ingresos_atribuidos)::NUMERIC / NULLIF(SUM(gasto),0) AS roas
FROM analytics.v_resumen_mensual_cliente
GROUP BY nombre_cliente, industria, estado_cliente
ORDER BY margen DESC;

/* Q2.3 — Clientes en RIESGO */
SELECT  nombre_cliente, industria, estado_cliente, anio_mes,
        facturacion_total, costo_interno, margen, margen_pct, roas,
        costo_interno_ratio, estado_pago,
        flag_margen_negativo, flag_roas_bajo, flag_costo_alto, flag_pago_tardio
FROM analytics.v_alertas_cartera
WHERE flag_margen_negativo OR flag_roas_bajo OR flag_costo_alto OR flag_pago_tardio
ORDER BY anio_mes DESC, margen ASC;

/* Q2.4 — Distribución por tipo de contrato */
SELECT  tipo_contrato,
        COUNT(DISTINCT id_cliente) AS n_clientes,
        SUM(facturacion_total)     AS facturacion,
        SUM(costo_interno)         AS costo_interno,
        SUM(margen)                AS margen,
        SUM(margen)::NUMERIC / NULLIF(SUM(facturacion_total),0) AS margen_pct
FROM analytics.v_resumen_mensual_cliente
WHERE tipo_contrato IS NOT NULL
GROUP BY tipo_contrato
ORDER BY margen DESC;

/* Q2.5 — Por industria y antigüedad */
SELECT  industria,
        CASE
            WHEN antiguedad_meses < 6  THEN '0-6 meses'
            WHEN antiguedad_meses < 12 THEN '6-12 meses'
            WHEN antiguedad_meses < 24 THEN '1-2 años'
            ELSE '2+ años'
        END AS rango_antiguedad,
        COUNT(DISTINCT id_cliente) AS n_clientes,
        AVG(margen_pct)            AS margen_pct_prom,
        AVG(roas)                  AS roas_prom
FROM analytics.v_resumen_mensual_cliente
GROUP BY industria,
         CASE
            WHEN antiguedad_meses < 6  THEN '0-6 meses'
            WHEN antiguedad_meses < 12 THEN '6-12 meses'
            WHEN antiguedad_meses < 24 THEN '1-2 años'
            ELSE '2+ años'
         END
ORDER BY industria, rango_antiguedad;


/* =============================================================================
   REPORTE 3 — CLIENTE (sección 6.3)
   En Power BI: slicer por nombre_cliente.
   Para pruebas manuales: cambiar el valor de app.id_cliente a continuación.
   Compatible con psql, pgAdmin, DBeaver y cualquier cliente PostgreSQL.
   ============================================================================= */

-- Cambiar '1' por el id_cliente que deseas consultar:
SET app.id_cliente TO '1';

/* Q3.1 — KPIs del cliente */
SELECT
    c.nombre_cliente,
    SUM(m.gasto)                      AS gasto,
    SUM(m.leads)                      AS leads,
    SUM(m.conversiones)               AS conversiones,
    SUM(m.ingresos_atribuidos)        AS ingresos,
    SUM(m.ingresos_atribuidos)::NUMERIC / NULLIF(SUM(m.gasto),0) AS roas,
    SUM(m.clicks)::NUMERIC  / NULLIF(SUM(m.impresiones),0)       AS ctr,
    SUM(m.gasto)::NUMERIC   / NULLIF(SUM(m.leads),0)             AS cpl,
    SUM(m.gasto)::NUMERIC   / NULLIF(SUM(m.conversiones),0)      AS cpa
FROM fct.metricas_ads_diarias m
JOIN dim.clientes c ON c.id_cliente = m.id_cliente
WHERE m.id_cliente = current_setting('app.id_cliente')::INTEGER
GROUP BY c.nombre_cliente;

/* Q3.2 — Tendencia diaria */
SELECT  fecha,
        SUM(gasto)               AS gasto,
        SUM(leads)               AS leads,
        SUM(ingresos_atribuidos) AS ingresos
FROM analytics.v_metricas_diarias
WHERE id_cliente = current_setting('app.id_cliente')::INTEGER
GROUP BY fecha
ORDER BY fecha;

/* Q3.3 — Estado de campañas */
SELECT  estado_campana,
        COUNT(*) AS n_campanas,
        SUM(gasto) AS gasto,
        SUM(ingresos_atribuidos) AS ingresos
FROM analytics.v_performance_campana
WHERE id_cliente = current_setting('app.id_cliente')::INTEGER
GROUP BY estado_campana;

/* Q3.4 — Ads ganadores del cliente */
SELECT  nombre_campana, formato, tema_creativo, tipo_audiencia, nivel_intencion,
        gasto, ingresos_atribuidos, roas, ctr, leads
FROM analytics.v_performance_ad
WHERE id_cliente = current_setting('app.id_cliente')::INTEGER
ORDER BY roas DESC NULLS LAST
LIMIT 10;

/* Q3.5 — Impacto de audiencia */
SELECT  tipo_audiencia, nivel_intencion,
        SUM(leads)               AS leads,
        SUM(ingresos_atribuidos) AS ingresos,
        SUM(gasto)               AS gasto,
        SUM(ingresos_atribuidos)::NUMERIC / NULLIF(SUM(gasto),0) AS roas
FROM analytics.v_performance_ad
WHERE id_cliente = current_setting('app.id_cliente')::INTEGER
GROUP BY tipo_audiencia, nivel_intencion
ORDER BY roas DESC NULLS LAST;

/* Q3.6 — Desempeño por plataforma del cliente */
SELECT  plataforma,
        SUM(gasto)               AS gasto,
        SUM(leads)               AS leads,
        SUM(conversiones)        AS conversiones,
        SUM(ingresos_atribuidos) AS ingresos,
        SUM(ingresos_atribuidos)::NUMERIC / NULLIF(SUM(gasto),0) AS roas
FROM analytics.v_metricas_diarias
WHERE id_cliente = current_setting('app.id_cliente')::INTEGER
GROUP BY plataforma;
