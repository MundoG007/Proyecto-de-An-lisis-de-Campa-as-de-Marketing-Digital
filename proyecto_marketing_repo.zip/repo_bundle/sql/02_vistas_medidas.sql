/* =============================================================================
   ARCHIVO  : 02_vistas_medidas.sql
   MOTOR    : PostgreSQL 13+
   OBJETIVO : Vistas analíticas reutilizables. Power BI consumirá estas vistas
              directamente — cada una responde a una necesidad del PDF.
   MÉTRICAS (según sección 5 del PDF):
       CTR   = clicks / impresiones
       CPC   = gasto / clicks
       CPL   = gasto / leads
       CPA   = gasto / conversiones
       ROAS  = ingresos_atribuidos / gasto
       Margen = facturacion_mensual.monto_total - costo_interno_del_mes
   ============================================================================= */

CREATE SCHEMA IF NOT EXISTS analytics;

/* -----------------------------------------------------------------------------
   V1. Métricas diarias enriquecidas por ad (grano: fecha - ad)
        Incluye joins a todas las dimensiones para que Power BI pueda filtrar.
   ----------------------------------------------------------------------------- */
CREATE OR REPLACE VIEW analytics.v_metricas_diarias AS
SELECT
    m.fecha,
    f.anio,
    f.mes,
    f.anio_mes,
    f.trimestre,
    -- Cliente
    c.id_cliente,
    c.nombre_cliente,
    c.industria,
    c.pais,
    c.moneda,
    c.estado_cliente,
    -- Campaña
    cp.id_campana,
    cp.nombre_campana,
    cp.plataforma,
    cp.objetivo,
    cp.estado_campana,
    -- Ad / Audiencia
    a.id_ad,
    a.formato,
    a.tema_creativo,
    a.estado_ad,
    au.id_audiencia,
    au.tipo_audiencia,
    au.nivel_intencion,
    -- Métricas base
    m.impresiones,
    m.clicks,
    m.gasto,
    m.leads,
    m.conversiones,
    m.ingresos_atribuidos
FROM fct.metricas_ads_diarias m
JOIN dim.fecha     f  ON f.fecha       = m.fecha
JOIN dim.ads       a  ON a.id_ad       = m.id_ad
JOIN dim.campanas  cp ON cp.id_campana = a.id_campana
LEFT JOIN dim.audiencias au ON au.id_audiencia = a.id_audiencia
JOIN dim.clientes  c  ON c.id_cliente  = m.id_cliente;


/* -----------------------------------------------------------------------------
   V2. Resumen mensual por cliente  (grano: mes - cliente)
        Base para Reporte Interno y KPIs cliente.
   ----------------------------------------------------------------------------- */
CREATE OR REPLACE VIEW analytics.v_resumen_mensual_cliente AS
WITH met AS (
    SELECT  m.id_cliente,
            TO_CHAR(m.fecha,'YYYY-MM') AS anio_mes,
            SUM(m.impresiones)         AS impresiones,
            SUM(m.clicks)              AS clicks,
            SUM(m.gasto)               AS gasto,
            SUM(m.leads)               AS leads,
            SUM(m.conversiones)        AS conversiones,
            SUM(m.ingresos_atribuidos) AS ingresos_atribuidos
    FROM fct.metricas_ads_diarias m
    GROUP BY m.id_cliente, TO_CHAR(m.fecha,'YYYY-MM')
),
hrs AS (
    SELECT  h.id_cliente,
            TO_CHAR(h.fecha,'YYYY-MM') AS anio_mes,
            SUM(h.horas)         AS horas_internas,
            SUM(h.costo_interno) AS costo_interno
    FROM fct.horas_agencia_diarias h
    GROUP BY h.id_cliente, TO_CHAR(h.fecha,'YYYY-MM')
)
SELECT
    c.id_cliente,
    c.nombre_cliente,
    c.industria,
    c.pais,
    c.moneda,
    c.estado_cliente,
    c.fecha_inicio_cliente,
    (EXTRACT(YEAR  FROM AGE(CURRENT_DATE, c.fecha_inicio_cliente))*12
   + EXTRACT(MONTH FROM AGE(CURRENT_DATE, c.fecha_inicio_cliente)))::INT AS antiguedad_meses,
    COALESCE(fm.mes, met.anio_mes, hrs.anio_mes)          AS anio_mes,
    fm.tipo_contrato,
    fm.fee_mensual,
    fm.monto_por_leads,
    fm.monto_revenue_share,
    COALESCE(fm.monto_total,0)                            AS facturacion_total,
    fm.estado_pago,
    COALESCE(met.gasto,0)                                 AS gasto,
    COALESCE(met.impresiones,0)                           AS impresiones,
    COALESCE(met.clicks,0)                                AS clicks,
    COALESCE(met.leads,0)                                 AS leads,
    COALESCE(met.conversiones,0)                          AS conversiones,
    COALESCE(met.ingresos_atribuidos,0)                   AS ingresos_atribuidos,
    COALESCE(hrs.horas_internas,0)                        AS horas_internas,
    COALESCE(hrs.costo_interno,0)                         AS costo_interno,
    COALESCE(fm.monto_total,0) - COALESCE(hrs.costo_interno,0) AS margen,
    CASE WHEN COALESCE(fm.monto_total,0) = 0 THEN NULL
         ELSE (COALESCE(fm.monto_total,0) - COALESCE(hrs.costo_interno,0))::NUMERIC / fm.monto_total
    END AS margen_pct,
    CASE WHEN COALESCE(met.gasto,0) = 0 THEN NULL
         ELSE met.ingresos_atribuidos::NUMERIC / met.gasto
    END AS roas,
    CASE WHEN COALESCE(fm.monto_total,0) = 0 THEN NULL
         ELSE COALESCE(hrs.costo_interno,0)::NUMERIC / fm.monto_total
    END AS costo_interno_ratio
FROM dim.clientes c
LEFT JOIN fct.facturacion_mensual fm ON fm.id_cliente = c.id_cliente
LEFT JOIN met                       ON met.id_cliente = c.id_cliente AND met.anio_mes = fm.mes
LEFT JOIN hrs                       ON hrs.id_cliente = c.id_cliente AND hrs.anio_mes = fm.mes;


/* -----------------------------------------------------------------------------
   V3. Performance por campaña (acumulado)  —  Reporte Comercial
   ----------------------------------------------------------------------------- */
CREATE OR REPLACE VIEW analytics.v_performance_campana AS
SELECT
    cp.id_campana,
    cp.nombre_campana,
    cp.plataforma,
    cp.objetivo,
    cp.estado_campana,
    c.id_cliente,
    c.nombre_cliente,
    SUM(m.impresiones)         AS impresiones,
    SUM(m.clicks)              AS clicks,
    SUM(m.gasto)               AS gasto,
    SUM(m.leads)               AS leads,
    SUM(m.conversiones)        AS conversiones,
    SUM(m.ingresos_atribuidos) AS ingresos_atribuidos,
    CASE WHEN SUM(m.impresiones)=0 THEN NULL ELSE SUM(m.clicks)::NUMERIC / SUM(m.impresiones) END AS ctr,
    CASE WHEN SUM(m.clicks)=0      THEN NULL ELSE SUM(m.gasto)::NUMERIC  / SUM(m.clicks)      END AS cpc,
    CASE WHEN SUM(m.leads)=0       THEN NULL ELSE SUM(m.gasto)::NUMERIC  / SUM(m.leads)       END AS cpl,
    CASE WHEN SUM(m.conversiones)=0 THEN NULL ELSE SUM(m.gasto)::NUMERIC / SUM(m.conversiones) END AS cpa,
    CASE WHEN SUM(m.gasto)=0       THEN NULL ELSE SUM(m.ingresos_atribuidos)::NUMERIC / SUM(m.gasto) END AS roas
FROM fct.metricas_ads_diarias m
JOIN dim.campanas cp ON cp.id_campana = m.id_campana
JOIN dim.clientes c  ON c.id_cliente  = m.id_cliente
GROUP BY cp.id_campana, cp.nombre_campana, cp.plataforma, cp.objetivo, cp.estado_campana,
         c.id_cliente, c.nombre_cliente;


/* -----------------------------------------------------------------------------
   V4. Performance por anuncio (ad) — creatividades ganadoras
   ----------------------------------------------------------------------------- */
CREATE OR REPLACE VIEW analytics.v_performance_ad AS
SELECT
    a.id_ad,
    a.formato,
    a.tema_creativo,
    a.estado_ad,
    cp.id_campana,
    cp.nombre_campana,
    cp.plataforma,
    c.id_cliente,
    c.nombre_cliente,
    au.tipo_audiencia,
    au.nivel_intencion,
    SUM(m.impresiones)         AS impresiones,
    SUM(m.clicks)              AS clicks,
    SUM(m.gasto)               AS gasto,
    SUM(m.leads)               AS leads,
    SUM(m.conversiones)        AS conversiones,
    SUM(m.ingresos_atribuidos) AS ingresos_atribuidos,
    CASE WHEN SUM(m.impresiones)=0 THEN NULL ELSE SUM(m.clicks)::NUMERIC/SUM(m.impresiones) END AS ctr,
    CASE WHEN SUM(m.gasto)=0       THEN NULL ELSE SUM(m.ingresos_atribuidos)::NUMERIC/SUM(m.gasto) END AS roas
FROM fct.metricas_ads_diarias m
JOIN dim.ads      a  ON a.id_ad      = m.id_ad
JOIN dim.campanas cp ON cp.id_campana = a.id_campana
JOIN dim.clientes c  ON c.id_cliente  = m.id_cliente
LEFT JOIN dim.audiencias au ON au.id_audiencia = a.id_audiencia
GROUP BY a.id_ad, a.formato, a.tema_creativo, a.estado_ad,
         cp.id_campana, cp.nombre_campana, cp.plataforma,
         c.id_cliente, c.nombre_cliente,
         au.tipo_audiencia, au.nivel_intencion;


/* -----------------------------------------------------------------------------
   V5. Alertas de cartera — Reporte Interno
   ----------------------------------------------------------------------------- */
CREATE OR REPLACE VIEW analytics.v_alertas_cartera AS
SELECT
    r.id_cliente,
    r.nombre_cliente,
    r.industria,
    r.estado_cliente,
    r.anio_mes,
    r.facturacion_total,
    r.costo_interno,
    r.margen,
    r.margen_pct,
    r.roas,
    r.costo_interno_ratio,
    r.estado_pago,
    (r.margen < 0)                                       AS flag_margen_negativo,
    (r.roas IS NOT NULL AND r.roas < 1)                  AS flag_roas_bajo,
    (r.costo_interno_ratio > 0.6)                        AS flag_costo_alto,
    (r.estado_pago IN ('Atrasado','Pendiente'))          AS flag_pago_tardio
FROM analytics.v_resumen_mensual_cliente r;
